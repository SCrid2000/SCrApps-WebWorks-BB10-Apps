function onLoad(data) {
	alert(data)
}